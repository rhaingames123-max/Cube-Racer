import { buildTrack, LAPS, CP_COUNT } from '../public/js/track.js';
import { createCar, stepCar } from '../public/js/sim.js';
import * as V from '../public/js/vec.js';

function run({ maxSpeedCap = null, useBoost = true, seconds = 400, slot = 0, verbose = true } = {}) {
  const track = buildTrack();
  const car = createCar(track, slot);
  const dt = 1 / 60;
  let minUpY = 1, maxY = 0, cps = [], lapTimes = [], upsideTicks = 0, jumpLand = 0, events = {};
  let lastLapT = 0;
  for (let i = 0; i < seconds * 60; i++) {
    const S = track.samples, N = track.N;
    const tgt = S[(car.idx + 7) % N].p;
    const dir = V.norm(V.sub(tgt, car.p));
    const right = V.cross(car.f, car.u);
    const steer = V.clamp(V.dot(dir, right) * 3.5, -1, 1);
    const inp = { steer, throttle: 1, brake: false, jump: false, boost: useBoost && car.grounded };
    if (maxSpeedCap && car.speed > maxSpeedCap) inp.throttle = 0;
    stepCar(car, inp, dt, track);
    minUpY = Math.min(minUpY, car.u[1]); maxY = Math.max(maxY, car.p[1]);
    if (car.u[1] < -0.5) upsideTicks++;
    for (const e of car.events) {
      if (typeof e === 'object') { cps.push(e.cp); if (e.cp === 0) { lapTimes.push(+(car.t - lastLapT).toFixed(1)); lastLapT = car.t; } }
      else events[e] = (events[e] || 0) + 1;
    }
    car.events.length = 0;
    if (Math.floor(car.seq / CP_COUNT) >= LAPS) break;
  }
  const ordered = cps.every((k, i) => k === ((i + 1) % CP_COUNT));
  if (verbose) console.log({ laps: Math.floor(car.seq / CP_COUNT), lapTimes, cpsOrdered: ordered, respawns: car.respawns, minUpY: +minUpY.toFixed(2), upsideDownSeconds: +(upsideTicks / 60).toFixed(2), maxHeight: +maxY.toFixed(1), events });
  return { laps: Math.floor(car.seq / CP_COUNT), respawns: car.respawns, ordered, upside: upsideTicks, cars: car };
}
console.log('--- full-speed bot (with boost) ---'); const a = run();
console.log('--- no boost, speed capped at 28 ---'); const b = run({ useBoost: false, maxSpeedCap: 28 });
console.log('--- slow bot capped at 18 (expect jump failures/respawns) ---'); run({ useBoost: false, maxSpeedCap: 18, seconds: 200 });
