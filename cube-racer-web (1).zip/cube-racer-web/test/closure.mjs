import { buildTrack, DS } from '../public/js/track.js';
const t = buildTrack();
console.log('samples', t.N, 'startIdx', t.startIdx, 'closeGap', t.closeGap.toFixed(2), 'closeAngle', t.closeAngle.toFixed(2));
const a = t.samples[0].p, b = t.samples[t.N-1].p;
console.log('first', a.map(x=>x.toFixed(1)), 'last', b.map(x=>x.toFixed(1)));
console.log('dx,dy,dz', (a[0]-b[0]).toFixed(2),(a[1]-b[1]).toFixed(2),(a[2]-b[2]).toFixed(2));
