import { buildTrack, CP_COUNT } from '../public/js/track.js';
import { createCar, stepCar } from '../public/js/sim.js';
import * as V from '../public/js/vec.js';
const track = buildTrack();
for (const cap of [18, 20, 22, 24, 26, 28, 30]) {
  const car = createCar(track, 0); const dt = 1/60; let r = 0, laps = 0;
  for (let i = 0; i < 90*60; i++) {
    const tgt = track.samples[(car.idx + 7) % track.N].p; const dir = V.norm(V.sub(tgt, car.p));
    const steer = V.clamp(V.dot(dir, V.cross(car.f, car.u)) * 3.5, -1, 1);
    stepCar(car, { steer, throttle: car.speed > cap ? 0 : 1, brake: false, jump: false, boost: false }, dt, track);
    car.events.length = 0;
    if (car.seq >= CP_COUNT) break;
  }
  console.log('speed cap', cap, '-> lap1 done:', car.seq >= CP_COUNT, 'respawns:', car.respawns, 'time', car.t.toFixed(1));
}
