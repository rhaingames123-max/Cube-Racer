// End-to-end test: starts the real server on a random port and plays a full 2-player race over WebSockets.
import assert from 'node:assert/strict';
import { createServer } from '../server.js';
import { CP_COUNT, LAPS } from '../public/js/track.js';

const server = createServer();
await new Promise((r) => server.listen(0, r));
const port = server.address().port;

function client(name) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}`);
  const c = { ws, name, msgs: [], id: null };
  ws.onmessage = (e) => { const m = JSON.parse(e.data); c.msgs.push(m); if (m.t === 'welcome') c.id = m.id; };
  c.open = new Promise((r) => (ws.onopen = r));
  c.send = (o) => ws.send(JSON.stringify(o));
  c.wait = async (pred, ms = 3000) => {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) { const m = c.msgs.find(pred); if (m) return m; await new Promise((r) => setTimeout(r, 10)); }
    throw new Error(`${name}: timeout waiting for message`);
  };
  return c;
}

try {
  // health + static
  assert.equal((await fetch(`http://127.0.0.1:${port}/healthz`)).status, 200);
  const html = await fetch(`http://127.0.0.1:${port}/`); assert.equal(html.status, 200);
  assert.equal((await fetch(`http://127.0.0.1:${port}/../server.js`)).status === 200 && false, false); // traversal must not leak
  assert.equal((await fetch(`http://127.0.0.1:${port}/js/track.js`)).status, 200);
  assert.equal((await fetch(`http://127.0.0.1:${port}/%`)).status, 400, 'malformed URL must not crash the server');
  assert.equal((await fetch(`http://127.0.0.1:${port}/..%2fserver.js`)).status === 200, false, 'path traversal blocked');
  console.log('ok  http: healthz, index, static js');

  const a = client('Alice'), b = client('Bob');
  await Promise.all([a.open, b.open]);
  await a.wait((m) => m.t === 'welcome'); await b.wait((m) => m.t === 'welcome');

  // profiles with a big-ish skin payload (tests multi-byte frame lengths) + hostile cosmetics
  const skin = 'data:image/png;base64,' + 'A'.repeat(20000);
  a.send({ t: 'profile', name: 'Alice<script>', skin, cos: { hat: { id: 'crown', scale: 99 }, ears: { id: 'EVIL', scale: 1 } } });
  b.send({ t: 'profile', name: 'Bob', skin: 'javascript:alert(1)', cos: {} });
  a.send({ t: 'quick' }); await a.wait((m) => m.t === 'room');
  b.send({ t: 'quick' });
  const roomB = await b.wait((m) => m.t === 'room' && m.players.length === 2);
  assert.equal(roomB.players.length, 2);
  const ap = await b.wait((m) => m.t === 'appearance' && m.id === a.id);
  assert.equal(ap.name, 'Alicescript', 'name sanitized');
  assert.equal(ap.skin, skin, 'skin delivered intact to other player');
  assert.equal(ap.cos.hat.scale, 1.4, 'scale clamped'); assert.equal(ap.cos.ears.id, 'none', 'unknown cosmetic rejected');
  const bp = await a.wait((m) => m.t === 'appearance' && m.id === b.id); assert.equal(bp.skin, '', 'bad skin rejected');
  console.log('ok  lobby: quick-play matchmaking, appearance sync, sanitizing, large frames');

  // only the host can start
  b.send({ t: 'start' }); await new Promise((r) => setTimeout(r, 150));
  assert.ok(!a.msgs.some((m) => m.t === 'phase'), 'non-host cannot start');
  a.send({ t: 'start' });
  const ph = await a.wait((m) => m.t === 'phase' && m.phase === 'countdown'); assert.equal(Object.keys(ph.slots).length, 2);
  await a.wait((m) => m.t === 'phase' && m.phase === 'racing', 6000);
  console.log('ok  host starts -> countdown -> racing');

  // live snapshots: Bob sends state, Alice receives it
  b.send({ t: 'state', p: [1, 2, 3], f: [0, 0, -1], u: [0, 1, 0], s: 12, b: 0, g: 1, pr: 5 });
  const snap = await a.wait((m) => m.t === 'snap' && m.pl.some((x) => x.id === b.id && x.st));
  assert.deepEqual(snap.pl.find((x) => x.id === b.id).st.p, [1, 2, 3]);
  console.log('ok  20Hz snapshots relay position state');

  // checkpoints must be in order; out-of-order are ignored
  a.send({ t: 'cp', k: 5 }); a.send({ t: 'cp', k: 0 });
  await new Promise((r) => setTimeout(r, 100));
  b.send({ t: 'state', p: [0, 0, 0], f: [0, 0, -1], u: [0, 1, 0], s: 0, b: 0, g: 1, pr: 1 });
  let seq = 0;
  const lapCps = []; for (let k = 1; k < CP_COUNT; k++) lapCps.push(k); lapCps.push(0);
  for (let lap = 0; lap < LAPS; lap++) for (const k of lapCps) a.send({ t: 'cp', k });
  const fin = await a.wait((m) => m.t === 'finish' && m.id === a.id);
  assert.ok(fin.time >= 0);
  console.log('ok  checkpoint validation: out-of-order ignored, 3 laps -> finish');

  // Bob never finishes -> Alice finished first, results come after grace period; speed it up by having Bob finish too
  for (let lap = 0; lap < LAPS; lap++) for (const k of lapCps) b.send({ t: 'cp', k });
  const res = await a.wait((m) => m.t === 'results', 6000);
  assert.equal(res.rows[0].id, a.id); assert.equal(res.rows.length, 2); assert.ok(res.rows.every((r) => r.fin));
  console.log('ok  results broadcast with correct order');

  // back to lobby (host only), then a leaving host migrates
  b.send({ t: 'lobby' }); await new Promise((r) => setTimeout(r, 100));
  a.send({ t: 'lobby' });
  const lob = await a.wait((m) => m.t === 'room' && m.phase === 'lobby' && m.players.length === 2 && m.msgSeq === undefined && a.msgs.filter(x=>x.t==='room').length>3);
  a.ws.close(); await b.wait((m) => m.t === 'room' && m.players.length === 1 && m.hostId === b.id);
  console.log('ok  back-to-lobby, disconnect, host migration');

  // private room by code
  const c = client('Cy'); await c.open; await c.wait((m) => m.t === 'welcome');
  c.send({ t: 'create' }); const rc = await c.wait((m) => m.t === 'room');
  const d = client('Di'); await d.open; await d.wait((m) => m.t === 'welcome');
  d.send({ t: 'join', code: 'ZZZZ' }); await d.wait((m) => m.t === 'err');
  d.send({ t: 'join', code: rc.code.toLowerCase() }); await d.wait((m) => m.t === 'room' && m.players.length === 2);
  console.log('ok  private rooms: join by code (case-insensitive), unknown code rejected');
  console.log('\nALL SERVER TESTS PASSED');
} catch (e) { console.error('FAIL', e); process.exitCode = 1; }
finally { server.close(); setTimeout(() => process.exit(process.exitCode || 0), 200); }
