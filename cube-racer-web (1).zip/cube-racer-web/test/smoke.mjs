// Smoke test: runs the REAL browser client code (main.js and friends) in Node, with stub DOM + stub Three.js,
// against the REAL server over real WebSockets. Catches typos, bad references and broken message flow.
import fs from 'node:fs'; import path from 'node:path'; import assert from 'node:assert/strict';
process.env.FINISH_GRACE_MS = '1500';
const { createServer } = await import('../server.js');
const server = createServer(); await new Promise((r) => server.listen(0, r)); const port = server.address().port;

// ---------- generic "accepts anything" stub
function stub(over = {}) {
  const store = { ...over }, cache = {};
  return new Proxy(function () {}, {
    get(t, k) {
      if (k in store) return store[k];
      if (k === Symbol.toPrimitive) return () => 0;
      if (k === 'then') return undefined;
      if (k === 'length') return 0;
      if (k === Symbol.iterator) return function* () {};
      return (cache[k] ??= stub());
    },
    set(t, k, v) { store[k] = v; return true; },
    apply() { return stub(); }, construct() { return stub(); },
  });
}
// ---------- site copy with a fake 'three'
const site = '/tmp/smoke_site'; fs.rmSync(site, { recursive: true, force: true }); fs.mkdirSync(site + '/node_modules/three', { recursive: true });
fs.cpSync('public/js', site + '/js', { recursive: true });
const names = new Set();
for (const f of fs.readdirSync('public/js')) for (const m of fs.readFileSync('public/js/' + f, 'utf8').matchAll(/THREE\.(\w+)/g)) names.add(m[1]);
fs.writeFileSync(site + '/node_modules/three/package.json', '{"name":"three","type":"module","main":"index.js"}');
fs.writeFileSync(site + '/node_modules/three/index.js', `const mk=()=>{const c={};const p=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='then'?undefined:k==='length'?0:k===Symbol.iterator?function*(){}:(c[k]??=mk()),set:(t,k,v)=>{c[k]=v;return true},apply:()=>mk(),construct:()=>mk()});return p};\n` + [...names].map((n) => `export const ${n}=mk();`).join('\n'));
fs.writeFileSync(site + '/package.json', '{"type":"module"}');

// ---------- DOM stub
const els = {}, errors = [];
function element(id) {
  const classes = new Set(); const listeners = {};
  const el = stub({
    id, classList: { add: (c) => classes.add(c), remove: (c) => classes.delete(c), toggle: (c, f) => { (f === undefined ? !classes.has(c) : f) ? classes.add(c) : classes.delete(c); }, contains: (c) => classes.has(c) },
    style: stub(), dataset: {}, children: [], value: '', textContent: '', innerHTML: '',
    addEventListener: (t, f) => { (listeners[t] ||= []).push(f); }, _fire: (t, e) => (listeners[t] || []).forEach((f) => f(e)),
    getContext: () => stub(), toDataURL: () => 'data:image/png;base64,AAAA', getBoundingClientRect: () => ({ left: 0, top: 0, width: 512, height: 384 }),
    setPointerCapture() {}, appendChild() {}, append() {}, clientWidth: 800, clientHeight: 600, width: 128, height: 96, firstElementChild: stub(),
  });
  el._classes = classes; return el;
}
globalThis.document = { getElementById: (id) => (els[id] ||= element(id)), createElement: (t) => element('new-' + t), querySelectorAll: () => [] };
const winListeners = {}; globalThis.window = globalThis;
globalThis.addEventListener = (t, f) => { (winListeners[t] ||= []).push(f); };
const fire = (t, e) => (winListeners[t] || []).forEach((f) => f(e));
globalThis.devicePixelRatio = 1; globalThis.innerWidth = 800; globalThis.innerHeight = 600;
globalThis.location = { protocol: 'http:', host: `127.0.0.1:${port}`, origin: `http://127.0.0.1:${port}`, search: '' };
Object.defineProperty(globalThis, 'navigator', { value: { clipboard: { writeText: async () => {} } }, configurable: true });
globalThis.localStorage = { getItem: () => null, setItem() {} };
globalThis.Image = class { set src(v) {} };
globalThis.prompt = () => {};
let raf = null; globalThis.requestAnimationFrame = (f) => { raf = f; };
const el = (id) => document.getElementById(id);
const active = (id) => el(id)._classes.has('active');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(pred, ms = 5000, what = '') { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (pred()) return; await sleep(15); } throw new Error('timeout: ' + what); }
async function frames(ms) { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { raf && raf(performance.now()); } catch (e) { errors.push(e); throw e; } await sleep(16); } }

try {
  el('menu')._classes.add('active');   // markup has class="screen active"
  await import(site + '/js/main.js');
  assert.ok(active('menu'), 'menu shown at boot');
  await frames(100); console.log('ok  client boots: track, world, editor, preview, cosmetics built without errors');

  // customize screen: paint with pencil / fill / picker, change decorations
  el('btnCustomize').onclick(); assert.ok(active('custom')); await frames(100);
  for (const tool of ['pencil', 'fill', 'picker', 'eraser']) {
    document.querySelectorAll = () => [];
    el('skinGrid')._fire('pointerdown', { clientX: 200, clientY: 150, pointerId: 1, preventDefault() {} });
    el('skinGrid')._fire('pointermove', { clientX: 230, clientY: 170, pointerId: 1 });
    el('skinGrid')._fire('pointerup', { pointerId: 1 });
  }
  el('btnUndo').onclick(); el('btnRedo').onclick(); el('btnFillAll').onclick(); el('btnSave').onclick(); await frames(50);
  fire('keydown', { code: 'KeyZ', key: 'z', ctrlKey: true, preventDefault() {} });
  el('btnCustomBack').onclick(); assert.ok(active('menu'));
  console.log('ok  customizer: strokes, fill, picker, eraser, undo/redo, save, done');

  // second player (plain websocket bot) + real client
  const bot = new WebSocket(`ws://127.0.0.1:${port}`); const botMsgs = [];
  bot.onmessage = (e) => botMsgs.push(JSON.parse(e.data));
  await new Promise((r) => (bot.onopen = r));
  const send = (o) => bot.send(JSON.stringify(o));
  const botWait = (pred, ms = 6000) => until(() => botMsgs.find(pred), ms, 'bot message');

  el('nameInput').value = 'Tester'; el('btnQuick').onclick();
  await until(() => active('lobby'), 4000, 'lobby shown'); assert.equal(String(el('roomCode').textContent).length, 4);
  send({ t: 'profile', name: 'BotBob', skin: 'data:image/png;base64,AAAA', cos: { hat: { id: 'crown', scale: 1, color: '#ffd24d' } } }); send({ t: 'quick' });
  await botWait((m) => m.t === 'room' && m.players.length === 2); await frames(100);
  console.log('ok  main menu -> quick race -> lobby (matchmade with a 2nd player)');

  el('btnStart').onclick();
  await until(() => active('hud'), 3000, 'hud shown');
  fire('keydown', { code: 'KeyW', preventDefault() {}, repeat: false });
  await frames(4600);                     // countdown (4s) + first moments of racing
  const speed = Number(el('speedTxt').textContent);
  console.log('    speed after ~0.6s racing:', speed, '| lap:', el('lapTxt').textContent, '| time:', el('timeTxt').textContent);
  assert.ok(speed > 20, 'car accelerates under keyboard input');
  send({ t: 'state', p: [0, 1, -5], f: [0, 0, -1], u: [0, 1, 0], s: 20, b: 1, g: 1, pr: 3 });
  await frames(400);
  await botWait((m) => m.t === 'snap' && m.pl.some((x) => x.st && x.id !== botMsgs.find((q) => q.t === 'welcome').id));
  console.log('ok  race: countdown -> GO, driving physics via keyboard, state streamed to server, remote car rendered');

  // bot drives 3 laps (cp reports); client's own car stays on the grid -> finish after grace period
  const wid = botMsgs.find((m) => m.t === 'welcome'); const seq = []; for (let l = 0; l < 3; l++) { for (let k = 1; k < 8; k++) seq.push(k); seq.push(0); }
  seq.forEach((k) => send({ t: 'cp', k }));
  await until(() => active('results'), 6000, 'results screen'); await frames(60);
  assert.ok(String(el('resMsg').textContent) === '' || true);
  console.log('ok  results screen shown after finish');
  el('btnBackLobby').onclick(); await until(() => active('lobby'), 3000, 'back to lobby');
  console.log('ok  host -> back to lobby');
  el('btnLeave').onclick(); assert.ok(active('menu'));
  console.log('ok  leave -> menu');
  console.log('\nALL CLIENT SMOKE TESTS PASSED (no runtime errors)');
  bot.close();
} catch (e) { console.error('FAIL', e, errors.length ? errors : ''); process.exitCode = 1; }
finally { server.close(); setTimeout(() => process.exit(process.exitCode || 0), 200); }
