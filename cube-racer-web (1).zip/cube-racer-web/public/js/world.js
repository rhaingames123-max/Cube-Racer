import * as THREE from 'three';
import * as V from './vec.js';
import { buildCosmetics } from './cosmetics.js';
import { FACES, COLS, ROWS } from './skin.js';

export { THREE };

// ------------------------------------------------------------------ cube mesh whose UVs match the T-shaped atlas
let _cubeGeo = null;
export function cubeGeometry() {
  if (_cubeGeo) return _cubeGeo;
  const geo = new THREE.BoxGeometry(1, 1, 1);
  // BoxGeometry face order: +x, -x, +y, -y, +z, -z. The car's front is -Z, its right side is +X.
  // Top/bottom are rotated 180deg so painting continues seamlessly across the T's folded edges.
  const order = [['left', false], ['right', false], ['top', true], ['bottom', true], ['back', false], ['front', false]];
  const uv = geo.attributes.uv;
  for (let f = 0; f < 6; f++) {
    const [name, rot] = order[f]; const [c, r] = FACES[name];
    for (let k = 0; k < 4; k++) {
      const i = f * 4 + k; let u = uv.getX(i), v = uv.getY(i);
      if (rot) { u = 1 - u; v = 1 - v; }
      uv.setXY(i, (c + u) / COLS, (ROWS - 1 - r + v) / ROWS);
    }
  }
  uv.needsUpdate = true;
  return (_cubeGeo = geo);
}

// ------------------------------------------------------------------ car view
const _m = new THREE.Matrix4(), _x = new THREE.Vector3(), _y = new THREE.Vector3(), _z = new THREE.Vector3();

function makeTag(name, gold) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(0,0,0,0.55)'; g.beginPath(); if (g.roundRect) g.roundRect(4, 8, 248, 48, 14); else g.rect(4, 8, 248, 48); g.fill();
  g.fillStyle = gold ? '#ffd24d' : '#ffffff'; g.font = 'bold 30px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(name, 128, 33, 232);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  s.scale.set(2.6, 0.65, 1);
  return s;
}

export class CarView {
  constructor(scene) {
    this.scene = scene;
    this.group = new THREE.Group(); scene.add(this.group);
    this.material = new THREE.MeshLambertMaterial({ color: '#4fa3ff' });
    this.body = new THREE.Mesh(cubeGeometry(), this.material); this.group.add(this.body);
    this.cos = null; this.tag = null; this.token = 0; this.tex = null;
    this.flame = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.9, 10).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#ff9d2e', transparent: true, opacity: 0.85 }));
    this.flame.position.set(0, 0, 0.95); this.flame.visible = false; this.group.add(this.flame);
  }
  _applyTexture(tex) {
    tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter; tex.generateMipmaps = false; tex.colorSpace = THREE.SRGBColorSpace;
    if (this.tex && this.tex !== tex) this.tex.dispose();
    this.tex = tex; this.material.map = tex; this.material.color.set('#ffffff'); this.material.needsUpdate = true;
  }
  setSkinURL(url) {
    const token = ++this.token;
    if (!url) { this.material.map = null; this.material.color.set('#4fa3ff'); this.material.needsUpdate = true; return; }
    new THREE.TextureLoader().load(url, (tex) => { if (token === this.token) this._applyTexture(tex); else tex.dispose(); });
  }
  setSkinCanvas(canvas) { this.token++; this._applyTexture(new THREE.CanvasTexture(canvas)); }
  refreshSkin() { if (this.tex) this.tex.needsUpdate = true; }
  setCosmetics(cos) {
    if (this.cos) { this.group.remove(this.cos); this.cos.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); }); }
    this.cos = buildCosmetics(THREE, cos); this.group.add(this.cos);
  }
  setName(name, gold) {
    if (this.tag) { this.scene.remove(this.tag); this.tag.material.map.dispose(); this.tag.material.dispose(); }
    this.tag = makeTag(name, gold); this.scene.add(this.tag);
  }
  setPose(p, f, u) {
    const r = V.norm(V.cross(f, u)), u2 = V.cross(r, f);
    _m.makeBasis(_x.set(r[0], r[1], r[2]), _y.set(u2[0], u2[1], u2[2]), _z.set(-f[0], -f[1], -f[2]));
    this.group.quaternion.setFromRotationMatrix(_m);
    this.group.position.set(p[0], p[1], p[2]);
    if (this.tag) this.tag.position.set(p[0], p[1] + 1.6, p[2]);
  }
  setBoost(on, time) {
    this.flame.visible = !!on;
    if (on) this.flame.scale.set(1, 1, 0.8 + 0.4 * Math.sin(time * 40));
  }
  dispose() {
    this.scene.remove(this.group);
    if (this.tag) { this.scene.remove(this.tag); this.tag.material.map.dispose(); this.tag.material.dispose(); }
    if (this.cos) this.cos.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
    if (this.tex) this.tex.dispose();
    this.material.dispose(); this.flame.geometry.dispose(); this.flame.material.dispose();
  }
}

// ------------------------------------------------------------------ camera
export class ChaseCam {
  constructor(camera) { this.camera = camera; this.pos = null; this.up = [0, 1, 0]; this.fov = 68; }
  reset() { this.pos = null; }
  update(dt, p, f, u, speed, boosting) {
    const want = V.madd(V.madd(p, f, -7.2), u, 3.3);
    if (!this.pos) { this.pos = want; this.up = u.slice(); }
    else {
      this.pos = V.lerp(this.pos, want, 1 - Math.exp(-14 * dt));
      this.up = V.norm(V.lerp(this.up, u, 1 - Math.exp(-3.5 * dt)));
    }
    const look = V.madd(V.madd(p, f, 3.5), u, 0.5);
    this.camera.up.set(this.up[0], this.up[1], this.up[2]);
    this.camera.position.set(this.pos[0], this.pos[1], this.pos[2]);
    this.camera.lookAt(look[0], look[1], look[2]);
    const wantFov = 68 + Math.min(1, Math.abs(speed) / 44) * 12 + (boosting ? 6 : 0);
    this.fov += (wantFov - this.fov) * (1 - Math.exp(-5 * dt));
    if (Math.abs(this.camera.fov - this.fov) > 0.05) { this.camera.fov = this.fov; this.camera.updateProjectionMatrix(); }
  }
}

// ------------------------------------------------------------------ track meshes
class MeshBuilder {
  constructor() { this.pos = []; this.col = []; this.idx = []; }
  quad(a, b, c, d, color) {
    const o = this.pos.length / 3;
    for (const p of [a, b, c, d]) { this.pos.push(p[0], p[1], p[2]); this.col.push(color.r, color.g, color.b); }
    this.idx.push(o, o + 1, o + 2, o, o + 2, o + 3);
  }
  mesh(material) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.setIndex(this.idx); g.computeVertexNormals();
    return new THREE.Mesh(g, material);
  }
}

function checkerTexture(cols, rows) {
  const c = document.createElement('canvas'); c.width = cols * 8; c.height = rows * 8;
  const g = c.getContext('2d');
  for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) { g.fillStyle = (x + y) % 2 ? '#111' : '#fff'; g.fillRect(x * 8, y * 8, 8, 8); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.magFilter = THREE.NearestFilter; return t;
}

function orient(obj, p, f, u) {
  const r = V.norm(V.cross(f, u));
  _m.makeBasis(_x.set(r[0], r[1], r[2]), _y.set(u[0], u[1], u[2]), _z.set(-f[0], -f[1], -f[2]));
  obj.quaternion.setFromRotationMatrix(_m); obj.position.set(p[0], p[1], p[2]);
}

function buildTrackMeshes(scene, track) {
  const S = track.samples, N = track.N, hw = track.hw;
  const road = new MeshBuilder(), curb = new MeshBuilder(), rail = new MeshBuilder(), pad = new MeshBuilder();
  const roadA = new THREE.Color('#3a404e'), roadB = new THREE.Color('#444b5b'), red = new THREE.Color('#e03a3a'), white = new THREE.Color('#f2f2f2');
  const railC = new THREE.Color('#6ab0ff'), padA = new THREE.Color('#ff9d00'), padB = new THREE.Color('#ffe14d');
  const at = (s, lat, up) => V.madd(V.madd(s.p, s.r, lat), s.u, up);

  for (let i = 0; i < N; i++) {
    const a = S[i], b = S[(i + 1) % N];
    if (a.gap || b.gap) continue;
    road.quad(at(a, -hw, 0), at(b, -hw, 0), at(b, hw, 0), at(a, hw, 0), (i >> 2) & 1 ? roadA : roadB);
    const cc = (i >> 1) & 1 ? red : white, cw = 0.9;
    curb.quad(at(a, -hw, 0.04), at(b, -hw, 0.04), at(b, -hw + cw, 0.04), at(a, -hw + cw, 0.04), cc);
    curb.quad(at(a, hw - cw, 0.04), at(b, hw - cw, 0.04), at(b, hw, 0.04), at(a, hw, 0.04), cc);
    rail.quad(at(a, -hw, 0), at(b, -hw, 0), at(b, -hw, 0.9), at(a, -hw, 0.9), railC);
    rail.quad(at(a, hw, 0), at(b, hw, 0), at(b, hw, 0.9), at(a, hw, 0.9), railC);
    if (a.boost && b.boost) pad.quad(at(a, -hw * 0.55, 0.07), at(b, -hw * 0.55, 0.07), at(b, hw * 0.55, 0.07), at(a, hw * 0.55, 0.07), (i >> 1) & 1 ? padA : padB);
  }
  scene.add(road.mesh(new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide })));
  scene.add(curb.mesh(new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide })));
  scene.add(rail.mesh(new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide, transparent: true, opacity: 0.5, depthWrite: false })));
  scene.add(pad.mesh(new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide })));

  // start / finish line + arch
  const s0 = S[track.startIdx];
  const line = new THREE.Mesh(new THREE.PlaneGeometry(hw * 2, 2.4), new THREE.MeshBasicMaterial({ map: checkerTexture(16, 2), side: THREE.DoubleSide }));
  const lp = V.madd(s0.p, s0.u, 0.09);
  const lm = new THREE.Matrix4().makeBasis(_x.set(...V.norm(V.cross(s0.f, s0.u))), _y.set(...s0.f), _z.set(...s0.u));
  line.quaternion.setFromRotationMatrix(lm); line.position.set(lp[0], lp[1], lp[2]); scene.add(line);
  const arch = new THREE.Group(); const pm = new THREE.MeshLambertMaterial({ color: '#d8dbe6' });
  for (const sx of [-1, 1]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.9, 8, 0.9), pm); p.position.set(sx * (hw + 0.9), 4, 0); arch.add(p); }
  const beam = new THREE.Mesh(new THREE.BoxGeometry((hw + 0.9) * 2 + 0.9, 1.7, 0.8), new THREE.MeshLambertMaterial({ map: checkerTexture(24, 2) }));
  beam.position.set(0, 8, 0); arch.add(beam);
  orient(arch, s0.p, s0.f, s0.u); scene.add(arch);

  // obstacles
  const om = new THREE.MeshLambertMaterial({ color: '#e8452e' });
  for (const o of track.obstacles) {
    const s = S[o.idx], b = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.6, 1.6), om);
    const p = V.madd(V.madd(s.p, s.r, o.s), s.u, 0.8); orient(b, p, s.f, s.u); scene.add(b);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.45, 0.35, 1.65), new THREE.MeshLambertMaterial({ color: '#ffffff' })); stripe.position.y = 0.2; b.add(stripe);
  }

  // ground + scenery (kept well away from the road)
  const gy = track.minY - 6;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(4000, 4000).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ color: '#4c9a58' }));
  ground.position.y = gy; scene.add(ground);
  let seed = 1337; const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  const palette = ['#e8d8b0', '#c9d6e8', '#e8b0b0', '#b8e0c0', '#f0c878'];
  for (let n = 0; n < 220 && scene.userData.deco < 70; n++) {
    scene.userData.deco = scene.userData.deco || 0;
    const x = (rnd() - 0.5) * 900, z = (rnd() - 0.5) * 900 + 150;
    let ok = true; for (let i = 0; i < N; i += 2) { const q = S[i].p; if ((q[0] - x) ** 2 + (q[2] - z) ** 2 < 45 * 45) { ok = false; break; } }
    if (!ok) continue;
    const h = 8 + rnd() * 40, w = 8 + rnd() * 14;
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), new THREE.MeshLambertMaterial({ color: palette[Math.floor(rnd() * palette.length)] }));
    b.position.set(x, gy + h / 2, z); scene.add(b); scene.userData.deco++;
  }
}

// ------------------------------------------------------------------ world / preview factories
function addLights(scene) {
  scene.add(new THREE.HemisphereLight('#ffffff', '#667788', 1.25));
  const sun = new THREE.DirectionalLight('#ffffff', 1.5); sun.position.set(60, 120, 40); scene.add(sun);
}

export function createWorld(canvas, track) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  const scene = new THREE.Scene(); scene.background = new THREE.Color('#8fc8ff'); scene.fog = new THREE.Fog('#8fc8ff', 140, 800);
  scene.userData.deco = 0;
  const camera = new THREE.PerspectiveCamera(68, 1, 0.1, 3000);
  addLights(scene); buildTrackMeshes(scene, track);
  const chase = new ChaseCam(camera);
  const start = track.samples[track.startIdx].p;
  const world = {
    renderer, scene, camera, chase,
    resize() { const w = canvas.clientWidth || innerWidth, h = canvas.clientHeight || innerHeight; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); },
    orbit(t) { // slow fly-around of the start straight (menus / lobby)
      const a = t * 0.12, R = 80;
      camera.up.set(0, 1, 0); camera.fov = 60; camera.updateProjectionMatrix();
      camera.position.set(start[0] + Math.cos(a) * R, start[1] + 30, start[2] - 30 + Math.sin(a) * R);
      camera.lookAt(start[0], start[1] + 2, start[2] - 30);
    },
    render() { renderer.render(scene, camera); },
  };
  world.resize(); addEventListener('resize', () => world.resize());
  return world;
}

export function createPreview(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  const scene = new THREE.Scene(); addLights(scene);
  const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 50); camera.position.set(0, 1.5, 4.4); camera.lookAt(0, 0.1, 0);
  const view = new CarView(scene);
  let yaw = Math.PI * 0.85, dragging = false, lastX = 0;
  canvas.style.touchAction = 'none';
  canvas.addEventListener('pointerdown', (e) => { dragging = true; lastX = e.clientX; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener('pointermove', (e) => { if (dragging) { yaw += (e.clientX - lastX) * 0.012; lastX = e.clientX; } });
  canvas.addEventListener('pointerup', () => { dragging = false; });
  return {
    view,
    render(dt) {
      if (!dragging) yaw += dt * 0.6;
      view.setPose([0, 0, 0], [Math.sin(yaw), 0, -Math.cos(yaw)], [0, 1, 0]);
      const w = canvas.clientWidth || 300, h = canvas.clientHeight || 300;
      if (canvas.width !== Math.floor(w * renderer.getPixelRatio())) { renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
      renderer.render(scene, camera);
    },
  };
}
