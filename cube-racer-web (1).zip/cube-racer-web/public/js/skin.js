// MS-Paint-style editor for the T-shaped cube skin. ONE canvas holds the whole atlas (128x96):
//
//             [ TOP ]
//   [LEFT]  [FRONT]  [RIGHT]  [BACK]          (as if you unfolded the cube looking at its face)
//             [BOTTOM]
//
// Each face is 32x32 pixels. Painting is locked to the face you started on, flood-fill never leaks
// across faces. The same canvas is used directly as the 3D texture, so edits show up live.
export const CELL = 32, COLS = 4, ROWS = 3, ATLAS_W = CELL * COLS, ATLAS_H = CELL * ROWS;
export const FACES = { top: [1, 0], left: [0, 1], front: [1, 1], right: [2, 1], back: [3, 1], bottom: [1, 2] };
const faceAt = (c, r) => Object.keys(FACES).find((k) => FACES[k][0] === c && FACES[k][1] === r) || null;

export const PALETTE = ['#000000', '#555555', '#aaaaaa', '#ffffff', '#ff4d4d', '#ff9d00', '#ffe14d', '#7be04d',
  '#1fa45a', '#4dd9e0', '#4fa3ff', '#2b4bff', '#8a4dff', '#ff4dd2', '#8b5a2b', '#ffc9a3'];

const hexToRgba = (hex) => { const n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, 255]; };

export class SkinEditor {
  constructor(canvas, overlay) {
    this.canvas = canvas; this.ctx = canvas.getContext('2d', { willReadFrequently: true });
    this.overlay = overlay; this.octx = overlay.getContext('2d');
    this.tool = 'pencil'; this.color = '#ff4d4d'; this.brush = 1; this.base = '#e8e8f0';
    this.undoStack = []; this.redoStack = []; this.listeners = [];
    this.stroke = null;
    this.drawOverlay();
    overlay.style.pointerEvents = 'auto'; overlay.style.touchAction = 'none';
    overlay.addEventListener('pointerdown', (e) => this.down(e));
    overlay.addEventListener('pointermove', (e) => this.move(e));
    overlay.addEventListener('pointerup', (e) => this.up(e));
    overlay.addEventListener('pointercancel', (e) => this.up(e));
  }
  onChange(fn) { this.listeners.push(fn); }
  emit() { this.listeners.forEach((f) => f()); }
  setTool(t) { this.tool = t; }
  setColor(c) { this.color = c; }
  setBrush(n) { this.brush = n; }

  // ---- whole-skin helpers
  makeDefault(color = '#4fa3ff') {
    const c = this.ctx; c.clearRect(0, 0, ATLAS_W, ATLAS_H);
    for (const [name, [col, row]] of Object.entries(FACES)) {
      c.fillStyle = color; c.fillRect(col * CELL, row * CELL, CELL, CELL);
      c.fillStyle = 'rgba(0,0,0,0.12)'; c.fillRect(col * CELL, row * CELL, CELL, 1); c.fillRect(col * CELL, row * CELL, 1, CELL);
    }
    const [fx, fy] = [FACES.front[0] * CELL, FACES.front[1] * CELL];   // a happy face on the front
    c.fillStyle = '#ffffff'; c.fillRect(fx + 7, fy + 9, 7, 8); c.fillRect(fx + 18, fy + 9, 7, 8);
    c.fillStyle = '#111111'; c.fillRect(fx + 10, fy + 12, 4, 5); c.fillRect(fx + 21, fy + 12, 4, 5);
    c.fillRect(fx + 9, fy + 22, 14, 2); c.fillRect(fx + 8, fy + 20, 2, 2); c.fillRect(fx + 22, fy + 20, 2, 2);
    this.undoStack = []; this.redoStack = []; this.emit();
  }
  fillAll(color) { this.snapshot(); for (const [c, r] of Object.values(FACES)) { this.ctx.fillStyle = color; this.ctx.fillRect(c * CELL, r * CELL, CELL, CELL); } this.emit(); }
  toDataURL() { return this.canvas.toDataURL('image/png'); }
  loadDataURL(url) {
    return new Promise((res) => {
      const img = new Image();
      img.onload = () => { this.ctx.clearRect(0, 0, ATLAS_W, ATLAS_H); this.ctx.drawImage(img, 0, 0, ATLAS_W, ATLAS_H); this.undoStack = []; this.redoStack = []; this.emit(); res(true); };
      img.onerror = () => res(false);
      img.src = url;
    });
  }

  // ---- undo / redo (whole-atlas snapshots - tiny at 128x96)
  snapshot() { this.undoStack.push(this.ctx.getImageData(0, 0, ATLAS_W, ATLAS_H)); if (this.undoStack.length > 50) this.undoStack.shift(); this.redoStack = []; }
  undo() { if (!this.undoStack.length) return; this.redoStack.push(this.ctx.getImageData(0, 0, ATLAS_W, ATLAS_H)); this.ctx.putImageData(this.undoStack.pop(), 0, 0); this.emit(); }
  redo() { if (!this.redoStack.length) return; this.undoStack.push(this.ctx.getImageData(0, 0, ATLAS_W, ATLAS_H)); this.ctx.putImageData(this.redoStack.pop(), 0, 0); this.emit(); }
  clearFaceAt(name) { const [c, r] = FACES[name]; this.snapshot(); this.ctx.fillStyle = this.base; this.ctx.fillRect(c * CELL, r * CELL, CELL, CELL); this.emit(); }

  // ---- pointer handling
  pos(e) {
    const r = this.overlay.getBoundingClientRect();
    return [Math.floor(((e.clientX - r.left) / r.width) * ATLAS_W), Math.floor(((e.clientY - r.top) / r.height) * ATLAS_H)];
  }
  down(e) {
    const [x, y] = this.pos(e);
    const face = faceAt(Math.floor(x / CELL), Math.floor(y / CELL));
    if (!face) return;
    e.preventDefault(); this.overlay.setPointerCapture(e.pointerId);
    const [c, r] = FACES[face];
    this.stroke = { face, x0: c * CELL, y0: r * CELL, last: null };
    if (this.tool === 'picker') { const d = this.ctx.getImageData(x, y, 1, 1).data; this.setColor('#' + [d[0], d[1], d[2]].map((v) => v.toString(16).padStart(2, '0')).join('')); this.listeners.forEach((f) => f('picked')); this.stroke = null; return; }
    this.snapshot();
    if (this.tool === 'fill') { this.floodFill(x, y); this.stroke = null; this.emit(); return; }
    this.dab(x, y); this.stroke.last = [x, y]; this.emit();
  }
  move(e) {
    if (!this.stroke) return;
    const [x, y] = this.pos(e); const l = this.stroke.last;
    if (l && l[0] === x && l[1] === y) return;
    this.line(l || [x, y], [x, y]); this.stroke.last = [x, y]; this.emit();
  }
  up() { this.stroke = null; }

  line(a, b) { // Bresenham so fast strokes have no gaps
    let [x0, y0] = a; const [x1, y1] = b;
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    for (;;) { this.dab(x0, y0); if (x0 === x1 && y0 === y1) break; const e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
  }
  dab(x, y) { // square brush, clipped to the face the stroke started on
    const s = this.stroke, b = this.brush, h = Math.floor(b / 2);
    const x1 = Math.max(s.x0, x - h), y1 = Math.max(s.y0, y - h), x2 = Math.min(s.x0 + CELL, x - h + b), y2 = Math.min(s.y0 + CELL, y - h + b);
    if (x2 <= x1 || y2 <= y1) return;
    this.ctx.fillStyle = this.tool === 'eraser' ? this.base : this.color;
    this.ctx.fillRect(x1, y1, x2 - x1, y2 - y1);
  }
  floodFill(sx, sy) {
    const { x0, y0 } = this.stroke;
    const img = this.ctx.getImageData(x0, y0, CELL, CELL), d = img.data;
    const px = sx - x0, py = sy - y0; const at = (x, y) => (y * CELL + x) * 4;
    const t = [d[at(px, py)], d[at(px, py) + 1], d[at(px, py) + 2], d[at(px, py) + 3]];
    const n = hexToRgba(this.color);
    if (t.every((v, i) => v === n[i])) return;
    const stack = [[px, py]];
    while (stack.length) {
      const [x, y] = stack.pop();
      if (x < 0 || y < 0 || x >= CELL || y >= CELL) continue;
      const i = at(x, y);
      if (d[i] !== t[0] || d[i + 1] !== t[1] || d[i + 2] !== t[2] || d[i + 3] !== t[3]) continue;
      d[i] = n[0]; d[i + 1] = n[1]; d[i + 2] = n[2]; d[i + 3] = 255;
      stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
    }
    this.ctx.putImageData(img, x0, y0);
  }

  drawOverlay() {
    const o = this.octx, W = this.overlay.width, H = this.overlay.height, cw = W / COLS, ch = H / ROWS;
    o.clearRect(0, 0, W, H);
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      const f = faceAt(c, r);
      if (!f) { o.fillStyle = 'rgba(10,14,30,0.78)'; o.fillRect(c * cw, r * ch, cw, ch); continue; }
      o.strokeStyle = 'rgba(255,255,255,0.7)'; o.lineWidth = 2; o.strokeRect(c * cw + 1, r * ch + 1, cw - 2, ch - 2);
      o.fillStyle = 'rgba(0,0,0,0.55)'; o.font = 'bold 13px system-ui, sans-serif'; o.fillRect(c * cw + 4, r * ch + 4, o.measureText(f.toUpperCase()).width + 10, 18);
      o.fillStyle = '#fff'; o.fillText(f.toUpperCase(), c * cw + 9, r * ch + 17);
    }
  }
}
