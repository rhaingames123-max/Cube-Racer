// Builds 3D cosmetic attachments (ears, eyes, horns, hats, wings, back items) from simple primitives.
// Cube is 1x1x1 centred on the origin: front = -Z, top = +Y, right = +X.
//
// SIZE LIMITS: every item is (1) scaled by the player's slider (clamped 0.6-1.4 in catalog.js) and then
// (2) hard-capped to a per-slot bounding box (CAPS below) so no cosmetic - whatever the slider says - can
// grow large enough to block other players' view of the road.
import { COSMETIC_SLOTS } from './catalog.js';

// max bounding-box size (cube units) of the whole slot item, after scaling
export const CAPS = {
  ears: [0.9, 0.55, 0.45], eyes: [0.9, 0.45, 0.3], horns: [0.8, 0.55, 0.45],
  hat: [0.75, 0.5, 0.75], wings: [2.0, 0.6, 0.65], back: [1.0, 0.6, 0.85],
};

export function buildCosmetics(THREE, cos) {
  const root = new THREE.Group();
  for (const slot of Object.keys(COSMETIC_SLOTS)) {
    const e = cos && cos[slot];
    if (!e || e.id === 'none') continue;
    const item = makeItem(THREE, slot, e.id, e.color || '#ffffff');
    if (!item) continue;
    item.scale.setScalar(e.scale || 1);
    root.add(item);
    root.updateMatrixWorld(true);
    const size = new THREE.Box3().setFromObject(item).getSize(new THREE.Vector3());
    const cap = CAPS[slot];
    const k = Math.min(1, cap[0] / size.x, cap[1] / size.y, cap[2] / size.z);
    if (k < 1) item.scale.multiplyScalar(k);
  }
  return root;
}

function makeItem(THREE, slot, id, color) {
  const g = new THREE.Group();
  const mat = (c) => new THREE.MeshLambertMaterial({ color: c });
  const main = mat(color), white = mat('#ffffff'), black = mat('#111111'), dark = mat('#222233');
  const add = (geo, m, x, y, z, rx = 0, ry = 0, rz = 0) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.rotation.set(rx, ry, rz); g.add(o); return o; };
  const cone = (r, h, seg = 12) => new THREE.ConeGeometry(r, h, seg);
  const box = (x, y, z) => new THREE.BoxGeometry(x, y, z);
  const ball = (r) => new THREE.SphereGeometry(r, 14, 10);
  const cyl = (r, h, seg = 16) => new THREE.CylinderGeometry(r, r, h, seg);

  // g's origin is the attach point; scaling the item scales it around that point.
  if (slot === 'ears') {
    g.position.set(0, 0.5, -0.1);
    if (id === 'cat') for (const s of [-1, 1]) add(cone(0.13, 0.28, 4), main, s * 0.3, 0.12, 0, 0, Math.PI / 4, s * -0.12);
    if (id === 'bunny') for (const s of [-1, 1]) add(box(0.12, 0.46, 0.06), main, s * 0.2, 0.22, 0, 0, 0, s * -0.1);
    if (id === 'bear') for (const s of [-1, 1]) add(ball(0.14), main, s * 0.32, 0.04, 0);
  } else if (slot === 'eyes') {
    g.position.set(0, 0.12, -0.5);
    if (id === 'round' || id === 'angry') {
      for (const s of [-1, 1]) { add(ball(0.12), white, s * 0.2, 0, -0.02); add(ball(0.06), black, s * 0.2, 0, -0.12); }
      if (id === 'angry') for (const s of [-1, 1]) add(box(0.26, 0.05, 0.04), black, s * 0.2, 0.15, -0.06, 0, 0, s * 0.45);
    }
    if (id === 'visor') { add(box(0.8, 0.16, 0.08), main, 0, 0.02, -0.03); add(box(0.8, 0.03, 0.09), dark, 0, 0.11, -0.03); }
  } else if (slot === 'horns') {
    g.position.set(0, 0.5, -0.15);
    if (id === 'small') for (const s of [-1, 1]) add(cone(0.07, 0.2, 8), main, s * 0.28, 0.1, 0);
    if (id === 'devil') for (const s of [-1, 1]) add(cone(0.07, 0.32, 8), main, s * 0.3, 0.14, 0, 0, 0, s * -0.35);
    if (id === 'unicorn') add(cone(0.07, 0.4, 10), main, 0, 0.2, 0);
  } else if (slot === 'hat') {
    g.position.set(0, 0.5, 0);
    if (id === 'tophat') { add(cyl(0.32, 0.03), main, 0, 0.015, 0); add(cyl(0.21, 0.3), main, 0, 0.17, 0); add(cyl(0.215, 0.05), mat('#cc3333'), 0, 0.07, 0); }
    if (id === 'party') add(cone(0.2, 0.42, 14), main, 0, 0.21, 0);
    if (id === 'crown') { add(cyl(0.25, 0.12, 20), mat('#ffd24d'), 0, 0.06, 0); for (let i = 0; i < 5; i++) { const a = (i / 5) * Math.PI * 2; add(cone(0.05, 0.14, 6), mat('#ffd24d'), Math.cos(a) * 0.22, 0.17, Math.sin(a) * 0.22); } }
    if (id === 'cap') { add(new THREE.SphereGeometry(0.28, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), main, 0, 0, 0); add(box(0.34, 0.03, 0.2), main, 0, 0.02, -0.3); }
  } else if (slot === 'wings') {
    g.position.set(0, 0.15, 0.12);
    if (id === 'small') for (const s of [-1, 1]) add(box(0.5, 0.04, 0.3), main, s * 0.78, 0.1, 0, 0, 0, s * 0.35);
    if (id === 'angel') for (const s of [-1, 1]) for (let i = 0; i < 3; i++) add(box(0.5 - i * 0.08, 0.04, 0.16), main, s * (0.8 - i * 0.04), 0.2 - i * 0.1, i * 0.02, 0, 0, s * (0.5 - i * 0.12));
  } else if (slot === 'back') {
    g.position.set(0, 0.5, 0.5);
    if (id === 'spoiler') { add(box(0.9, 0.05, 0.2), main, 0, 0.12, 0.08); for (const s of [-1, 1]) add(box(0.05, 0.14, 0.05), dark, s * 0.3, 0.04, 0.05); }
    if (id === 'antenna') { add(cyl(0.015, 0.45, 6), dark, 0.25, 0.22, -0.2); add(ball(0.055), main, 0.25, 0.46, -0.2); }
    if (id === 'tail') { g.position.set(0, -0.1, 0.5); add(box(0.06, 0.06, 0.5), main, 0, 0.08, 0.25, 0.35, 0, 0); add(ball(0.07), main, 0, 0.28, 0.48); }
  }
  return g.children.length ? g : null;
}
