// Arcade cube physics - pure math, no engine. Same design as the Unity version:
//  * rotation is fully scripted (nothing can tumble the cube)
//  * yaw follows steering immediately
//  * pitch/roll ("up") smoothly follows the road surface under the cube - ramps, banks, walls, loops
//  * in the air the orientation is HELD, then smoothly realigns on landing
import * as V from './vec.js';
import { CP_COUNT, LAPS } from './track.js';

export const PHYS = {
  hover: 0.5,        // cube centre height above road
  accel: 30, maxSpeed: 30, boostMax: 44, boostAccel: 60,
  brake: 48, drag: 7, reverseMax: 10,
  turn: 108,         // deg/sec at low speed
  gravity: 34, jump: 9.5,
  align: 9,          // rad/sec the cube's "up" chases the surface normal
  airTurn: 0.45, railInset: 0.65, slope: 0.2,
};

export function createCar(track, slot) {
  const row = Math.floor(slot / 2), side = slot % 2 ? 1 : -1;
  const rel = -(2 + row * 2);
  const idx = (track.startIdx + rel + track.N * 4) % track.N;
  const s = track.samples[idx];
  return {
    p: V.madd(V.madd(s.p, s.u, PHYS.hover), s.r, side * 3.5), v: [0, 0, 0],
    f: s.f.slice(), u: s.u.slice(), speed: 0, grounded: true, idx,
    tp: rel, seq: 0,                  // tp = unwrapped track position (in samples, 0 = start line); seq = checkpoints crossed
    boostT: 0, boostCd: 0, noGroundUntil: 0, t: 0, hitCd: 0, lastGroundT: 0, respawns: 0, events: [],
  };
}

/** Closest road frame to point p (searching near `hint`, or the whole track when global). */
export function queryRoad(track, p, hint, global = false) {
  const S = track.samples, N = track.N;
  let best = hint, bd = Infinity;
  if (global) { for (let i = 0; i < N; i++) { const d = V.dist2(p, S[i].p); if (d < bd) { bd = d; best = i; } } }
  else { for (let k = -14; k <= 14; k++) { const i = (hint + k + N * 2) % N; const d = V.dist2(p, S[i].p); if (d < bd) { bd = d; best = i; } } }
  const s0 = S[best];
  const along = V.dot(V.sub(p, s0.p), s0.f);
  let a, b, t;
  if (along >= 0) { a = best; b = (best + 1) % N; t = Math.min(1, along / track.ds); }
  else { a = (best - 1 + N) % N; b = best; t = Math.max(0, 1 + along / track.ds); }
  const A = S[a], B = S[b];
  const pos = V.lerp(A.p, B.p, t), u = V.norm(V.lerp(A.u, B.u, t)), r = V.norm(V.lerp(A.r, B.r, t)), f = V.norm(V.lerp(A.f, B.f, t));
  const d = V.sub(p, pos);
  return {
    idx: best, pos, u, r, f, h: V.dot(d, u), s: V.dot(d, r), gap: A.gap || B.gap || s0.gap, boost: s0.boost,
    dist: V.len(d), convex: V.dot(V.sub(B.u, A.u), f) / track.ds,
  };
}

export function respawnCar(car, track) {
  const k = car.seq % CP_COUNT;
  const rel = k === 0 ? 0 : track.cpRel[k];
  const idx = (track.startIdx + rel) % track.N;
  const s = track.samples[idx];
  car.p = V.madd(s.p, s.u, PHYS.hover); car.v = [0, 0, 0]; car.f = s.f.slice(); car.u = s.u.slice();
  car.speed = 0; car.grounded = true; car.idx = idx; car.boostT = 0; car.noGroundUntil = 0;
  car.tp = Math.floor(car.seq / CP_COUNT) * track.N + rel;
  car.respawns++; car.events.push('respawn');
}

function moveToward(x, target, d) { return x < target ? Math.min(target, x + d) : Math.max(target, x - d); }

function trackProgress(car, track) {
  const N = track.N;
  const rel = (((car.idx - track.startIdx) % N) + N) % N;
  const cur = ((car.tp % N) + N) % N;
  let d = rel - cur;
  if (d > N / 2) d -= N; else if (d < -N / 2) d += N;
  car.tp += d;
  for (let guard = 0; guard < 3; guard++) {
    const s1 = car.seq + 1, k = s1 % CP_COUNT;
    const target = Math.floor(s1 / CP_COUNT) * N + (k === 0 ? 0 : track.cpRel[k]);
    if (car.tp >= target) { car.seq++; car.events.push({ cp: k }); } else break;
  }
}

/** Advance one car by dt seconds. input = {steer(-1..1, +right), throttle(-1..1), brake, jump, boost} (jump/boost are one-shot). */
export function stepCar(car, inp, dt, track) {
  const P = PHYS;
  car.t += dt;
  if (car.boostT > 0) car.boostT -= dt;
  if (car.boostCd > 0) car.boostCd -= dt;
  if (car.hitCd > 0) car.hitCd -= dt;
  if (inp.boost && car.boostCd <= 0) { car.boostT = 1.4; car.boostCd = 3.5; car.events.push('boost'); }

  const road = queryRoad(track, car.p, car.idx);
  car.idx = road.idx;
  trackProgress(car, track);

  // ---- grounded?
  const vn = V.dot(car.v, road.u);
  const tol = car.grounded ? P.hover + 0.45 : P.hover + 0.08;
  const onRoad = !road.gap && Math.abs(road.s) <= track.hw + 0.4;
  let ground = onRoad && road.h <= tol && road.h >= -0.8 && car.t >= car.noGroundUntil && (car.grounded || vn <= 1.0);
  if (ground) car.lastGroundT = car.t;

  // convex crest at speed -> launch (hill jumps)
  if (ground && car.grounded && road.convex > 0.02 && car.speed * car.speed * road.convex > P.gravity * Math.max(0.3, road.u[1]) * 1.3) {
    ground = false; car.noGroundUntil = car.t + 0.12; car.v = V.mul(car.f, car.speed);
  }
  // jump (with a little coyote time)
  if (inp.jump && (ground || car.t - car.lastGroundT < 0.1)) {
    car.v = V.madd(V.mul(car.f, car.speed), car.u, P.jump);
    ground = false; car.noGroundUntil = car.t + 0.2; car.events.push('jump');
  }

  const sf = 1 - 0.45 * V.clamp(Math.abs(car.speed) / P.maxSpeed, 0, 1);
  const turnRate = P.turn * V.DEG * sf * V.clamp(Math.abs(car.speed) / 5, 0.35, 1);

  if (ground) {
    if (!car.grounded) { car.events.push('land'); car.grounded = true; car.speed = Math.max(0, V.dot(car.v, car.f)) * 0.98 + Math.min(0, V.dot(car.v, car.f)); }
    // surface alignment: "up" chases the road normal; forward is re-projected onto the new plane
    car.u = V.rotTowards(car.u, road.u, P.align * dt);
    let f = V.projPlane(car.f, car.u);
    car.f = V.len(f) > 1e-4 ? V.norm(f) : road.f.slice();
    car.f = V.norm(V.rotAxis(car.f, car.u, -inp.steer * turnRate * dt)); // + steer = turn right

    // speed
    const top = car.boostT > 0 ? P.boostMax : P.maxSpeed;
    if (road.boost) { car.boostT = Math.max(car.boostT, 1.1); }
    if (inp.brake && car.speed > 0) car.speed = Math.max(0, car.speed - P.brake * dt);
    else if (inp.throttle > 0) {
      if (car.speed < top) car.speed = Math.min(top, car.speed + (car.boostT > 0 ? P.boostAccel : P.accel) * inp.throttle * dt);
      else car.speed = Math.max(top, car.speed - P.drag * 2 * dt);
    } else if (inp.throttle < 0) car.speed = Math.max(-P.reverseMax, car.speed - (car.speed > 0 ? P.brake : P.accel * 0.6) * dt);
    else car.speed = moveToward(car.speed, 0, P.drag * dt);
    car.speed -= P.gravity * P.slope * car.f[1] * dt; // uphill slows, downhill speeds up

    // obstacles
    if (car.hitCd <= 0) {
      for (const o of track.obstacles) {
        let di = Math.abs(o.idx - car.idx); di = Math.min(di, track.N - di);
        if (di <= 1 && Math.abs(road.s - o.s) < 1.5) { car.speed *= 0.35; car.hitCd = 0.8; car.events.push('hit'); break; }
      }
    }

    car.v = V.mul(car.f, car.speed);
    car.p = V.madd(car.p, car.v, dt);

    // stick to the surface + side rails
    const r1 = queryRoad(track, car.p, car.idx);
    if (!r1.gap) {
      car.p = V.madd(car.p, r1.u, P.hover - r1.h);
      const lim = track.hw - P.railInset;
      if (Math.abs(r1.s) > lim) {
        car.p = V.madd(car.p, r1.r, -(r1.s - Math.sign(r1.s) * lim));
        const fl = V.dot(car.f, r1.r);
        if (fl * Math.sign(r1.s) > 0) { const g = V.sub(car.f, V.mul(r1.r, fl)); if (V.len(g) > 0.2) car.f = V.norm(g); car.speed *= 0.985; }
      }
    }
  } else {
    if (car.grounded) { car.grounded = false; }
    // airborne: orientation is held (up unchanged); only yaw around it, reduced
    let f = V.projPlane(car.f, car.u);
    if (V.len(f) > 1e-4) car.f = V.norm(V.rotAxis(V.norm(f), car.u, -inp.steer * turnRate * P.airTurn * dt));
    car.v = V.madd(car.v, [0, -1, 0], P.gravity * dt);
    car.p = V.madd(car.p, car.v, dt);
    car.speed = V.dot(car.v, car.f);
  }

  if (road.dist > 45 || car.p[1] < track.minY - 25) respawnCar(car, track);
}
