// Shared (browser + server) list of cosmetic ids and limits. The server uses it to reject anything unknown.
export const COSMETIC_SLOTS = {
  ears:  ['none', 'cat', 'bunny', 'bear'],
  eyes:  ['none', 'round', 'angry', 'visor'],
  horns: ['none', 'small', 'devil', 'unicorn'],
  hat:   ['none', 'tophat', 'party', 'crown', 'cap'],
  wings: ['none', 'small', 'angel'],
  back:  ['none', 'spoiler', 'antenna', 'tail'],
};
export const SLOT_LABELS = { ears: 'Ears', eyes: 'Eyes', horns: 'Horns', hat: 'Hat', wings: 'Wings', back: 'Back' };
export const DEFAULT_COLORS = { ears: '#ffb3c6', eyes: '#ffffff', horns: '#ff5a5a', hat: '#2b2b2b', wings: '#ffffff', back: '#ff9d00' };
export const SCALE_MIN = 0.6;   // user size slider range - clamped again by hard per-slot size caps in cosmetics.js
export const SCALE_MAX = 1.4;
export const MAX_NAME = 16;
export const MAX_SKIN_CHARS = 120000;

export function sanitizeCosmetics(c) {
  const out = {};
  for (const slot of Object.keys(COSMETIC_SLOTS)) {
    const e = c && c[slot];
    const id = e && typeof e.id === 'string' && COSMETIC_SLOTS[slot].includes(e.id) ? e.id : 'none';
    let s = e && Number(e.scale);
    if (!Number.isFinite(s)) s = 1;
    const color = e && typeof e.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(e.color) ? e.color : DEFAULT_COLORS[slot];
    out[slot] = { id, scale: Math.max(SCALE_MIN, Math.min(SCALE_MAX, s)), color };
  }
  return out;
}
export function sanitizeName(n) {
  n = String(n == null ? '' : n).replace(/[^\w \-.!]/g, '').trim().slice(0, MAX_NAME);
  return n || 'Racer';
}
export function sanitizeSkin(s) {
  return typeof s === 'string' && s.startsWith('data:image/png;base64,') && s.length <= MAX_SKIN_CHARS ? s : '';
}
