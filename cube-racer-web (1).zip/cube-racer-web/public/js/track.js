// Procedural track: a "turtle" walks the course and drops road samples (position + full orientation frame).
// Ramps, banks, walls and a vertical loop are all just different frame orientations - the car physics only
// ever asks "what is the road frame under me?", so every surface type uses the exact same code path.
import { DEG, add, sub, mul, madd, dot, cross, norm, rotAxis } from './vec.js';

export const LAPS = 3;
export const CP_COUNT = 8;
export const HALF_W = 7;
export const DS = 1.5; // spacing between road samples

export function buildTrack() {
  let p = [0, 0, 0], f = [0, 0, -1], u0 = [0, 1, 0], r0 = [1, 0, 0]; // path frame (unbanked)
  let roll = 0;                                                       // bank angle applied to the road surface only
  const samples = [];
  const obstacles = [];

  function ortho() { r0 = norm(cross(f, u0)); u0 = norm(cross(r0, f)); }
  function rot(yaw, pitch) {
    if (yaw) { f = rotAxis(f, u0, yaw); r0 = rotAxis(r0, u0, yaw); }
    if (pitch) { f = rotAxis(f, r0, pitch); u0 = rotAxis(u0, r0, pitch); }
  }
  function push(fl) {
    ortho();
    samples.push({ p: p.slice(), f: f.slice(), u: rotAxis(u0, f, roll), r: rotAxis(r0, f, roll), gap: !!fl.gap, boost: !!fl.boost });
  }
  function step(len, yaw, pitch, lat, fl) {
    rot(yaw / 2, pitch / 2);
    p = madd(p, f, len);
    if (lat) p = madd(p, r0, lat);
    rot(yaw / 2, pitch / 2);
    push(fl);
  }

  const S = (len, fl = {}) => { const n = Math.max(1, Math.round(len / DS)); for (let i = 0; i < n; i++) step(len / n, 0, 0, 0, fl); };
  // Turn: +deg = left. Bank leans the road into the turn (inside edge lower).
  const T = (deg, radius, bank = 0, fl = {}) => {
    const ang = deg * DEG, arc = Math.abs(ang) * radius, n = Math.max(2, Math.round(arc / DS));
    for (let i = 0; i < n; i++) {
      const t = (i + 1) / n;
      roll = -Math.sign(deg) * bank * DEG * Math.min(1, 2.2 * Math.sin(Math.PI * t));
      step(arc / n, ang / n, 0, 0, fl);
    }
    roll = 0;
  };
  const P = (deg, len, fl = {}) => { const n = Math.max(2, Math.round(len / DS)); for (let i = 0; i < n; i++) step(len / n, 0, deg * DEG / n, 0, fl); };
  const LOOP = (radius, shift) => { const arc = 2 * Math.PI * radius, n = Math.round(arc / DS); for (let i = 0; i < n; i++) step(arc / n, 0, 2 * Math.PI / n, shift / n, {}); };
  const GAP = (len, deg) => P(deg, len, { gap: true });
  const OBS = (lateral) => obstacles.push({ idx: samples.length - 1, s: lateral });

  // ---------------- course (counter-clockwise) ----------------
  push({});                       // sample 0
  S(28);                          // grid / run-up
  const startIdx = samples.length - 1;
  S(30);                          // <- start/finish line is startIdx
  S(36, { boost: true });         // boost pad strip
  S(84);
  T(180, 34, 24);                 // hairpin 1 (banked)
  S(14);
  S(24, { boost: true });         // boost pad before the jump
  P(17, 6); S(8); GAP(10, -45);   // kicker ramp + short gap (path pitches down across it = steep landing slope)
  P(28, 7);                       // flatten out
  S(14);
  P(-4, 8); S(0.9); P(4, 8);      // gentle dip back to ground level
  S(10); OBS(-3);
  S(10); OBS(3);
  S(10); OBS(-3.5);
  S(12);
  LOOP(13, 17);                   // vertical loop (helix-shifted so the exit doesn't overlap the entry)
  S(16);
  T(40, 45, 16); T(-80, 45, 16); T(40, 45, 16); // chicane
  S(30);
  T(180, 42.5, 24);               // hairpin 2 (banked)
  S(123.1);

  return finish(samples, obstacles, startIdx);
}

function finish(samples, obstacles, startIdx) {
  const N = samples.length;
  const first = samples[0], last = samples[N - 1];
  let minY = Infinity;
  for (const s of samples) minY = Math.min(minY, s.p[1]);
  const cpRel = [];
  for (let k = 0; k < CP_COUNT; k++) cpRel.push(Math.round((k * N) / CP_COUNT));
  return {
    samples, obstacles, N, startIdx, cpRel, hw: HALF_W, ds: DS, minY,
    closeGap: Math.hypot(...sub(last.p, first.p)) , // distance from last sample to first (should be ~ DS when closed)
    closeAngle: Math.acos(Math.min(1, Math.max(-1, dot(last.f, first.f)))) / DEG,
    cpAbs: cpRel.map((r) => (startIdx + r) % N),
  };
}
