// Tiny WebSocket client with typed message handlers.
export class Net {
  constructor() { this.ws = null; this.handlers = {}; }
  on(type, fn) { this.handlers[type] = fn; return this; }
  get open() { return this.ws && this.ws.readyState === WebSocket.OPEN; }
  connect() {
    if (this.open) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const url = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}`;
      const ws = (this.ws = new WebSocket(url));
      let settled = false;
      ws.onopen = () => { settled = true; resolve(); };
      ws.onerror = () => { if (!settled) { settled = true; reject(new Error('Could not reach the game server')); } };
      ws.onclose = () => { if (this.ws === ws) { this.ws = null; (this.handlers.close || (() => {}))(); } };
      ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch { return; } (this.handlers[m.t] || (() => {}))(m); };
    });
  }
  send(o) { if (this.open) this.ws.send(JSON.stringify(o)); }
  close() { if (this.ws) { const w = this.ws; this.ws = null; w.close(); } }
}
