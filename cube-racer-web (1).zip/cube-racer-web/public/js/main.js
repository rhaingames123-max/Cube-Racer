import { createWorld, createPreview, CarView } from './world.js';
import { buildTrack, LAPS, CP_COUNT } from './track.js';
import { createCar, stepCar, respawnCar } from './sim.js';
import * as V from './vec.js';
import { SkinEditor, PALETTE } from './skin.js';
import { COSMETIC_SLOTS, SLOT_LABELS, SCALE_MIN, SCALE_MAX, sanitizeCosmetics, sanitizeName } from './catalog.js';
import { Net } from './net.js';

const $ = (id) => document.getElementById(id);
const STEP = 1 / 60;
const r2 = (a) => [Math.round(a[0] * 100) / 100, Math.round(a[1] * 100) / 100, Math.round(a[2] * 100) / 100];

// ------------------------------------------------------------------ saved profile (skin, decorations, name, saved skins)
const STORE = 'cuberacer.profile.v1';
function loadProfile() {
  try {
    const j = JSON.parse(localStorage.getItem(STORE));
    if (j) return { name: typeof j.name === 'string' ? j.name.slice(0, 16) : '', skin: typeof j.skin === 'string' ? j.skin : '', cos: sanitizeCosmetics(j.cos), saved: Array.isArray(j.saved) ? j.saved.slice(0, 20) : [] };
  } catch {}
  return { name: '', skin: '', cos: sanitizeCosmetics({}), saved: [] };
}
const profile = loadProfile();
let saveTimer = 0;
let skinDirty = false;
const saveProfile = () => { if (skinDirty) { profile.skin = editor.toDataURL(); skinDirty = false; } try { localStorage.setItem(STORE, JSON.stringify(profile)); } catch {} };
const saveSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(saveProfile, 500); };

// ------------------------------------------------------------------ world, state
const track = buildTrack();
const world = createWorld($('gl'), track);
const net = new Net();

const S = {
  screen: 'menu', phase: 'menu', id: null, room: null, apps: new Map(),
  views: new Map(), cur: new Map(), tgt: new Map(), rk: [], laps: LAPS,
  me: null, prev: null, acc: 0, steer: 0, finished: false, countdownEnd: 0, raceT0: 0, lastSend: 0, goFlash: 0, results: null,
};

const screens = ['menu', 'custom', 'lobby', 'hud', 'results'];
function show(name) { for (const s of screens) $(s).classList.toggle('active', s === name); S.screen = name; }
let toastTimer = 0;
function toast(msg, ms = 1600) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), ms); }
const menuMsg = (m) => { $('menuMsg').textContent = m || ''; };

// ------------------------------------------------------------------ skin editor + customization screen
const editor = new SkinEditor($('skinCanvas'), $('skinGrid'));
if (!profile.skin || !(await editor.loadDataURL(profile.skin))) editor.makeDefault();
profile.skin = editor.toDataURL();
$('nameInput').value = profile.name;

const preview = createPreview($('previewCanvas'));
preview.view.setSkinCanvas(editor.canvas);
preview.view.setCosmetics(profile.cos);

editor.onChange((kind) => {
  if (kind === 'picked') { $('colorInput').value = editor.color; return; }
  preview.view.refreshSkin();
  skinDirty = true; saveSoon();
});

document.querySelectorAll('[data-tool]').forEach((b) => b.addEventListener('click', () => {
  editor.setTool(b.dataset.tool);
  document.querySelectorAll('[data-tool]').forEach((x) => x.classList.toggle('on', x === b));
}));
$('brush').addEventListener('input', (e) => editor.setBrush(+e.target.value));
$('colorInput').addEventListener('input', (e) => editor.setColor(e.target.value));
for (const c of PALETTE) {
  const sw = document.createElement('i'); sw.style.background = c; sw.title = c;
  sw.addEventListener('click', () => { editor.setColor(c); $('colorInput').value = c; });
  $('palette').appendChild(sw);
}
$('btnUndo').onclick = () => editor.undo();
$('btnRedo').onclick = () => editor.redo();
$('btnFillAll').onclick = () => editor.fillAll(editor.color);
$('btnReset').onclick = () => editor.makeDefault(editor.color);
addEventListener('keydown', (e) => {
  if (S.screen !== 'custom' || !(e.ctrlKey || e.metaKey)) return;
  if (e.key === 'z') { e.preventDefault(); e.shiftKey ? editor.redo() : editor.undo(); }
  if (e.key === 'y') { e.preventDefault(); editor.redo(); }
});

// decorations (ears / eyes / horns / hat / wings / back)
const cosCtl = {};
function buildCosUI() {
  const box = $('cosList'); box.innerHTML = '';
  for (const slot of Object.keys(COSMETIC_SLOTS)) {
    const row = document.createElement('div'); row.className = 'cosrow';
    const label = document.createElement('label'); label.textContent = SLOT_LABELS[slot];
    const sel = document.createElement('select');
    for (const id of COSMETIC_SLOTS[slot]) { const o = document.createElement('option'); o.value = id; o.textContent = id === 'none' ? 'None' : id[0].toUpperCase() + id.slice(1); sel.appendChild(o); }
    const range = document.createElement('input'); range.type = 'range'; range.min = SCALE_MIN; range.max = SCALE_MAX; range.step = 0.05; range.title = 'Size';
    const col = document.createElement('input'); col.type = 'color'; col.title = 'Colour';
    const update = () => { profile.cos[slot] = { id: sel.value, scale: +range.value, color: col.value }; preview.view.setCosmetics(profile.cos); saveSoon(); };
    sel.onchange = range.oninput = col.oninput = update;
    row.append(label, sel, range, col); box.appendChild(row);
    cosCtl[slot] = { sel, range, col };
  }
  syncCosUI();
}
function syncCosUI() { for (const slot of Object.keys(cosCtl)) { const c = profile.cos[slot]; cosCtl[slot].sel.value = c.id; cosCtl[slot].range.value = c.scale; cosCtl[slot].col.value = c.color; } }
buildCosUI();

// saved skins (skin + decorations together)
function renderSaved() {
  const ul = $('savedList'); ul.innerHTML = '';
  if (!profile.saved.length) { ul.innerHTML = '<li><span style="color:#9aa4cc">Nothing saved yet</span></li>'; return; }
  profile.saved.forEach((item, i) => {
    const li = document.createElement('li'); const name = document.createElement('span'); name.textContent = item.name;
    const load = document.createElement('button'); load.textContent = 'Load';
    load.onclick = async () => { if (await editor.loadDataURL(item.skin)) { profile.cos = sanitizeCosmetics(item.cos); syncCosUI(); preview.view.setCosmetics(profile.cos); profile.skin = editor.toDataURL(); saveProfile(); } };
    const del = document.createElement('button'); del.textContent = '✕';
    del.onclick = () => { profile.saved.splice(i, 1); saveProfile(); renderSaved(); };
    li.append(name, load, del); ul.appendChild(li);
  });
}
$('btnSave').onclick = () => {
  const name = $('saveName').value.trim() || `Skin ${profile.saved.length + 1}`;
  profile.saved.unshift({ name, skin: editor.toDataURL(), cos: JSON.parse(JSON.stringify(profile.cos)) });
  profile.saved = profile.saved.slice(0, 20); $('saveName').value = ''; saveProfile(); renderSaved();
};
renderSaved();

function openCustom() { preview.view.setCosmetics(profile.cos); show('custom'); }
function closeCustom() { skinDirty = true; profile.name = $('nameInput').value; saveProfile(); sendProfile(); show(S.room && S.room.phase === 'lobby' ? 'lobby' : 'menu'); }
$('btnCustomize').onclick = openCustom;
$('btnLobbyCustom').onclick = openCustom;
$('btnCustomBack').onclick = closeCustom;

// ------------------------------------------------------------------ networking
const sendProfile = () => net.send({ t: 'profile', name: profile.name, skin: profile.skin, cos: profile.cos });

async function ensureConnected() {
  if (net.open) { if (S.id) return; } else S.id = null;
  await net.connect();
  const t0 = performance.now();
  while (!S.id) { if (performance.now() - t0 > 6000) throw new Error('The server did not answer'); await new Promise((r) => setTimeout(r, 20)); }
}
async function go(msg) {
  try { menuMsg('Connecting…'); profile.name = $('nameInput').value; saveProfile(); await ensureConnected(); sendProfile(); net.send(msg); menuMsg(''); }
  catch (e) { menuMsg(e.message); }
}
$('nameInput').addEventListener('input', () => { profile.name = $('nameInput').value; saveSoon(); });
$('btnQuick').onclick = () => go({ t: 'quick' });
$('btnCreate').onclick = () => go({ t: 'create' });
$('btnJoin').onclick = () => { const code = $('codeInput').value.trim(); if (code.length < 4) return menuMsg('Enter the 4-letter room code'); go({ t: 'join', code }); };
$('btnStart').onclick = () => net.send({ t: 'start' });
$('btnBackLobby').onclick = () => net.send({ t: 'lobby' });
const leave = () => { net.send({ t: 'leave' }); S.room = null; endRace(); show('menu'); menuMsg(''); };
$('btnLeave').onclick = leave; $('btnResLeave').onclick = leave;
$('btnCopy').onclick = async () => {
  const link = `${location.origin}/?room=${S.room ? S.room.code : ''}`;
  try { await navigator.clipboard.writeText(link); $('lobbyMsg').textContent = 'Invite link copied!'; } catch { prompt('Copy this invite link:', link); }
};

net.on('welcome', (m) => { S.id = m.id; })
  .on('err', (m) => { menuMsg(m.msg); $('lobbyMsg').textContent = m.msg; })
  .on('appearance', onAppearance)
  .on('room', onRoom)
  .on('left', (m) => { removeRacer(m.id); S.apps.delete(m.id); })
  .on('phase', onPhase)
  .on('snap', onSnap)
  .on('finish', (m) => { if (m.id !== S.id) toast(`🏁 ${nameOf(m.id)} finished!`, 1800); })
  .on('results', onResults)
  .on('close', () => { S.id = null; S.room = null; endRace(); show('menu'); menuMsg('Disconnected from the server. Press Quick Race to reconnect.'); });

const nameOf = (id) => (S.apps.get(id) || {}).name || (S.room && (S.room.players.find((p) => p.id === id) || {}).name) || 'Racer';

function drawThumb(cv, skin) {
  const g = cv.getContext('2d'); g.imageSmoothingEnabled = false; g.fillStyle = '#4fa3ff'; g.fillRect(0, 0, 32, 32);
  if (!skin) return;
  const img = new Image(); img.onload = () => g.drawImage(img, 32, 32, 32, 32, 0, 0, 32, 32); img.src = skin; // front face cell
}
function renderLobby() {
  const room = S.room; if (!room) return;
  $('roomCode').textContent = room.code;
  const ul = $('playerList'); ul.innerHTML = '';
  for (const p of room.players) {
    const li = document.createElement('li'); const cv = document.createElement('canvas'); cv.width = cv.height = 32;
    drawThumb(cv, (S.apps.get(p.id) || {}).skin);
    const nm = document.createElement('span'); nm.textContent = p.name + (p.id === S.id ? ' (you)' : '');
    li.append(cv, nm);
    if (p.id === room.hostId) { const b = document.createElement('span'); b.className = 'badge'; b.textContent = 'HOST'; li.appendChild(b); }
    ul.appendChild(li);
  }
  const host = room.hostId === S.id;
  $('btnStart').style.display = host ? '' : 'none';
  $('lobbyMsg').textContent = host ? (room.players.length < 2 ? 'Tip: you can start alone for a practice run.' : '') : 'Waiting for the host to start…';
}
function onAppearance(m) {
  S.apps.set(m.id, { name: m.name, skin: m.skin, cos: m.cos });
  const v = S.views.get(m.id); if (v && m.id !== S.id) applyAppearance(v, m.id);
  if (S.screen === 'lobby') renderLobby();
}
function onRoom(m) {
  S.room = m;
  if (m.phase === 'lobby') { if (S.phase !== 'menu' && S.phase !== 'lobby') endRace(); S.phase = 'lobby'; if (S.screen !== 'custom') show('lobby'); renderLobby(); }
}

// ------------------------------------------------------------------ race lifecycle
function applyAppearance(view, id) {
  const a = S.apps.get(id) || { skin: '', cos: sanitizeCosmetics({}) };
  view.setName(nameOf(id), id === S.id); view.setSkinURL(a.skin); view.setCosmetics(sanitizeCosmetics(a.cos));
}
function poseOf(c) { return { p: c.p.slice(), f: c.f.slice(), u: c.u.slice() }; }
function removeRacer(id) { const v = S.views.get(id); if (v) { v.dispose(); S.views.delete(id); } S.cur.delete(id); S.tgt.delete(id); }
function endRace() {
  for (const id of [...S.views.keys()]) removeRacer(id);
  S.me = null; S.prev = null; S.rk = []; S.finished = false; S.phase = 'lobby'; world.chase.reset();
}

function onPhase(m) {
  if (m.phase === 'countdown') {
    endRace(); S.laps = m.laps; S.phase = 'countdown'; S.finished = false; S.acc = 0; S.steer = 0;
    for (const [idStr, slot] of Object.entries(m.slots)) {
      const id = Number(idStr), car = createCar(track, slot), v = new CarView(world.scene);
      S.views.set(id, v); applyAppearance(v, id);
      v.setPose(car.p, car.f, car.u);
      if (id === S.id) { S.me = car; S.prev = poseOf(car); } else { S.cur.set(id, poseOf(car)); }
    }
    S.countdownEnd = performance.now() + m.ms;
    show('hud'); $('toast').classList.remove('show'); $('standings').textContent = '';
  } else if (m.phase === 'racing') {
    S.phase = 'racing'; S.raceT0 = performance.now(); S.goFlash = performance.now() + 900;
  }
}
function onSnap(m) {
  S.rk = m.rk;
  for (const e of m.pl) {
    if (e.id === S.id || !e.st) continue;
    const t = S.tgt.get(e.id); S.tgt.set(e.id, { ...e.st, lap: e.lap, fin: e.fin });
    if (!t && S.cur.has(e.id)) { const c = S.cur.get(e.id); c.p = e.st.p.slice(); c.f = e.st.f.slice(); c.u = e.st.u.slice(); }
  }
}
function fmtTime(ms) { const s = ms / 1000, m = Math.floor(s / 60); return `${m}:${(s - m * 60).toFixed(1).padStart(4, '0')}`; }
function onResults(m) {
  S.phase = 'results';
  const tb = $('resultRows'); tb.innerHTML = '';
  for (const r of m.rows) {
    const tr = document.createElement('tr'); if (r.id === S.id) tr.className = 'me';
    const cells = [r.pos + '.', r.name, r.fin ? fmtTime(r.time) : 'DNF'];
    for (const c of cells) { const td = document.createElement('td'); td.textContent = c; tr.appendChild(td); }
    tb.appendChild(tr);
  }
  const host = S.room && S.room.hostId === S.id;
  $('btnBackLobby').style.display = host ? '' : 'none';
  $('resMsg').textContent = host ? '' : 'Waiting for the host to go back to the lobby…';
  show('results');
}

// ------------------------------------------------------------------ input (keyboard + touch buttons)
const keys = new Set(), touch = {}, queued = { jump: false, boost: false };
addEventListener('keydown', (e) => {
  keys.add(e.code);
  if (S.screen !== 'hud') return;
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
  if (e.repeat) return;
  if (e.code === 'Space') queued.jump = true;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') queued.boost = true;
  if (e.code === 'KeyR' && S.phase === 'racing' && S.me) { respawnCar(S.me, track); S.prev = poseOf(S.me); S.me.events.length = 0; toast('Respawned', 900); }
});
addEventListener('keyup', (e) => keys.delete(e.code));
addEventListener('blur', () => keys.clear());
document.querySelectorAll('#touch [data-k]').forEach((b) => {
  const k = b.dataset.k;
  b.addEventListener('pointerdown', (e) => { e.preventDefault(); touch[k] = true; if (k === 'jump') queued.jump = true; if (k === 'boost') queued.boost = true; });
  for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) b.addEventListener(ev, () => { touch[k] = false; });
});
const down = (codes, tk) => codes.some((c) => keys.has(c)) || !!touch[tk];

function readInput(dt) {
  const target = (down(['ArrowRight', 'KeyD'], 'right') ? 1 : 0) - (down(['ArrowLeft', 'KeyA'], 'left') ? 1 : 0);
  S.steer += (target - S.steer) * Math.min(1, dt * 9);   // smooth keyboard steering
  const throttle = (down(['ArrowUp', 'KeyW'], 'gas') ? 1 : 0) - (down(['ArrowDown', 'KeyS'], 'brake') ? 1 : 0);
  const inp = { steer: S.steer, throttle, brake: false, jump: queued.jump, boost: queued.boost };
  queued.jump = queued.boost = false;
  return inp;
}

function simStep() {
  const me = S.me, before = Math.floor(me.seq / CP_COUNT);
  stepCar(me, readInput(STEP), STEP, track);
  for (const e of me.events) {
    if (typeof e === 'object') { if (!S.finished) net.send({ t: 'cp', k: e.cp }); }
    else if (e === 'respawn') { S.prev = poseOf(me); toast('Respawned', 900); }
    else if (e === 'hit') toast('BONK!', 700);
    else if (e === 'boost') toast('BOOST!', 600);
  }
  me.events.length = 0;
  const laps = Math.floor(me.seq / CP_COUNT);
  if (laps > before && laps < S.laps) toast(`LAP ${laps + 1}/${S.laps}`, 1400);
  if (laps >= S.laps && !S.finished) { S.finished = true; toast('🏁 FINISH!', 3000); }
}

// ------------------------------------------------------------------ frame loop
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now; const t = now / 1000;
  if (S.screen === 'custom') { preview.render(dt); return; }
  if (S.me && (S.phase === 'countdown' || S.phase === 'racing')) raceFrame(dt, now, t); else world.orbit(t);
  world.render();
}

function raceFrame(dt, now, t) {
  const me = S.me;
  if (S.phase === 'racing') {
    S.acc += dt;
    while (S.acc >= STEP) { S.prev = poseOf(me); simStep(); S.acc -= STEP; }
    if (now - S.lastSend > 50) {
      S.lastSend = now;
      net.send({ t: 'state', p: r2(me.p), f: r2(me.f), u: r2(me.u), s: Math.round(me.speed * 10) / 10, b: me.boostT > 0 ? 1 : 0, g: me.grounded ? 1 : 0, pr: Math.round(me.tp * 100) / 100 });
    }
  }
  // draw our own car interpolated between the last two physics steps
  const a = S.phase === 'racing' ? S.acc / STEP : 1;
  const p = V.lerp(S.prev.p, me.p, a), f = V.norm(V.lerp(S.prev.f, me.f, a)), u = V.norm(V.lerp(S.prev.u, me.u, a));
  const mine = S.views.get(S.id); mine.setPose(p, f, u); mine.setBoost(me.boostT > 0, t);
  world.chase.update(dt, p, f, u, me.speed, me.boostT > 0);

  // other racers: ease toward the latest network snapshot (with a little forward prediction)
  const k = 1 - Math.exp(-14 * dt);
  for (const [id, view] of S.views) {
    if (id === S.id) continue;
    const c = S.cur.get(id), g = S.tgt.get(id); if (!c) continue;
    if (g) {
      const want = V.madd(g.p, g.f, g.s * 0.06);
      c.p = V.lerp(c.p, want, k); c.f = V.norm(V.lerp(c.f, g.f, k)); c.u = V.norm(V.lerp(c.u, g.u, k));
    }
    view.setPose(c.p, c.f, c.u); view.setBoost(g && g.b, t);
  }
  updateHud(now, me);
}

function updateHud(now, me) {
  const cd = $('countdown');
  if (S.phase === 'countdown') { const n = Math.ceil((S.countdownEnd - now) / 1000); cd.textContent = n > 0 ? n : 'GO!'; }
  else cd.textContent = now < S.goFlash ? 'GO!' : '';
  const lap = Math.min(S.laps, Math.floor(me.seq / CP_COUNT) + 1);
  $('lapTxt').textContent = `LAP ${lap}/${S.laps}`;
  $('timeTxt').textContent = S.phase === 'racing' ? fmtTime(now - S.raceT0) : '0:00.0';
  const place = S.rk.indexOf(S.id) + 1, total = S.views.size;
  $('posTxt').innerHTML = `${place || 1}<small>/${total}</small>`;
  $('speedTxt').textContent = Math.round(Math.abs(me.speed) * 3.6);
  const bar = $('boostBar'); bar.classList.toggle('on', me.boostT > 0);
  bar.firstElementChild.style.width = (me.boostT > 0 ? Math.min(100, (me.boostT / 1.4) * 100) : Math.max(0, 100 - (me.boostCd / 3.5) * 100)) + '%';
  if (S.rk.length) {
    const html = S.rk.slice(0, 8).map((id, i) => `<div class="${id === S.id ? 'me' : ''}">${i + 1}. ${esc(nameOf(id))}</div>`).join('');
    if ($('standings').dataset.h !== html) { $('standings').innerHTML = html; $('standings').dataset.h = html; }
  }
}
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ------------------------------------------------------------------ boot
requestAnimationFrame(frame);
const roomParam = new URLSearchParams(location.search).get('room');
if (roomParam) { $('codeInput').value = roomParam.slice(0, 4).toUpperCase(); go({ t: 'join', code: roomParam }); }
